@app.post("/cart/add")
def add_to_cart(product_id: int, quantity: int = 1):

    # 🔍 Find product
    for product in products:
        if product["id"] == product_id:

            # ❌ Out of stock check
            if not product["in_stock"]:
                raise HTTPException(
                    status_code=400,
                    detail=f"{product['name']} is out of stock"
                )

            # 🔁 Check if already in cart
            for item in cart:
                if item["product_id"] == product_id:
                    # Update quantity
                    item["quantity"] += quantity
                    item["subtotal"] = item["quantity"] * item["unit_price"]

                    return {
                        "message": "Cart updated",
                        "cart_item": item
                    }

            # ➕ If not in cart → add new
            subtotal = product["price"] * quantity

            cart_item = {
                "product_id": product["id"],
                "product_name": product["name"],
                "quantity": quantity,
                "unit_price": product["price"],
                "subtotal": subtotal
            }

            cart.append(cart_item)

            return {
                "message": "Added to cart",
                "cart_item": cart_item
            }

    # ❌ Product not found
    raise HTTPException(
        status_code=404,
        detail="Product not found"
    )