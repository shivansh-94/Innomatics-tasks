from fastapi import FastAPI, HTTPException

app = FastAPI()

# Product catalog (as per your scenario)
products = [
    {"id": 1, "name": "Wireless Mouse", "price": 499, "category": "Electronics", "in_stock": True},
    {"id": 2, "name": "Notebook", "price": 99, "category": "Stationery", "in_stock": True},
    {"id": 3, "name": "USB Hub", "price": 649, "category": "Electronics", "in_stock": True}
]

# Cart list
cart = []


# ✅ Add item to cart
@app.post("/cart/add")
def add_to_cart(product_id: int, quantity: int):
    
    # Find product
    for product in products:
        if product["id"] == product_id:

            if not product["in_stock"]:
                raise HTTPException(status_code=400, detail="Product out of stock")

            # Calculate subtotal
            subtotal = product["price"] * quantity

            cart_item = {
                "product_id": product["id"],
                "product_name": product["name"],
                "quantity": quantity,
                "unit_price": product["price"],
                "subtotal": subtotal
            }

            cart.append(cart_item)

            return {
                "message": "Added to cart",
                "cart_item": cart_item
            }

    # Product not found
    raise HTTPException(status_code=404, detail="Product not found")