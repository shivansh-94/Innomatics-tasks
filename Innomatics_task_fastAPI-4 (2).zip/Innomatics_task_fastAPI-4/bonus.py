from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI()

# Sample data
products = [
    {"id": 1, "name": "Wireless Mouse", "price": 499, "in_stock": True},
    {"id": 2, "name": "Notebook", "price": 99, "in_stock": True}
]

cart = []
orders = []


# =========================
# 👀 VIEW CART
# =========================
@app.get("/cart")
def view_cart():
    if not cart:
        return {"message": "Cart is empty"}

    grand_total = sum(item["subtotal"] for item in cart)

    return {
        "items": cart,
        "item_count": len(cart),
        "grand_total": grand_total
    }


# =========================
# 💳 CHECKOUT (WITH EMPTY CART VALIDATION)
# =========================
class CheckoutRequest(BaseModel):
    customer_name: str
    delivery_address: str


@app.post("/cart/checkout")
def checkout(data: CheckoutRequest):

    # ❌ IMPORTANT: Handle empty cart
    if not cart:
        raise HTTPException(
            status_code=400,
            detail="CART_EMPTY"
        )

    created_orders = []

    # Create orders (1 per item)
    for item in cart:
        order = {
            "order_id": len(orders) + 1,
            "customer_name": data.customer_name,
            "delivery_address": data.delivery_address,
            "product": item["product_name"],
            "quantity": item["quantity"],
            "total_price": item["subtotal"]
        }

        orders.append(order)
        created_orders.append(order)

    # Clear cart
    cart.clear()

    return {
        "message": "Order placed successfully",
        "orders_placed": len(created_orders),
        "orders": created_orders
    }


# =========================
# 📋 VIEW ORDERS
# =========================
@app.get("/orders")
def get_orders():
    return {
        "total_orders": len(orders),
        "orders": orders
    }