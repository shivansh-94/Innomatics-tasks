from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI()

# 🛍️ Products
products = [
    {"id": 1, "name": "Wireless Mouse", "price": 499, "in_stock": True},
    {"id": 2, "name": "Notebook", "price": 99, "in_stock": True},
    {"id": 3, "name": "USB Hub", "price": 649, "in_stock": False},
    {"id": 4, "name": "Pen Set", "price": 49, "in_stock": True}
]

# 🛒 Cart + 📦 Orders
cart = []
orders = []


# =========================
# ➕ ADD TO CART
# =========================
@app.post("/cart/add")
def add_to_cart(product_id: int, quantity: int = 1):

    for product in products:
        if product["id"] == product_id:

            if not product["in_stock"]:
                raise HTTPException(
                    status_code=400,
                    detail=f"{product['name']} is out of stock"
                )

            # 🔁 Update if already exists
            for item in cart:
                if item["product_id"] == product_id:
                    item["quantity"] += quantity
                    item["subtotal"] = item["quantity"] * item["unit_price"]

                    return {
                        "message": "Cart updated",
                        "cart_item": item
                    }

            # ➕ Add new item
            subtotal = product["price"] * quantity

            cart_item = {
                "product_id": product["id"],
                "product_name": product["name"],
                "quantity": quantity,
                "unit_price": product["price"],
                "subtotal": subtotal
            }

            cart.append(cart_item)

            return {
                "message": "Added to cart",
                "cart_item": cart_item
            }

    raise HTTPException(status_code=404, detail="Product not found")


# =========================
# 👀 VIEW CART
# =========================
@app.get("/cart")
def view_cart():

    if not cart:
        return {"message": "Cart is empty"}

    grand_total = sum(item["subtotal"] for item in cart)

    return {
        "items": cart,
        "item_count": len(cart),
        "grand_total": grand_total
    }


# =========================
# 🗑️ REMOVE FROM CART
# =========================
@app.delete("/cart/{product_id}")
def remove_from_cart(product_id: int):

    for i, item in enumerate(cart):
        if item["product_id"] == product_id:
            removed = item["product_name"]
            cart.pop(i)

            return {"message": f"{removed} removed from cart"}

    raise HTTPException(status_code=404, detail="Item not in cart")


# =========================
# 💳 CHECKOUT (1 ORDER PER PRODUCT)
# =========================
class CheckoutRequest(BaseModel):
    customer_name: str
    delivery_address: str


@app.post("/cart/checkout")
def checkout(data: CheckoutRequest):

    if not cart:
        raise HTTPException(status_code=400, detail="Cart is empty")

    created_orders = []

    # 🔥 Create 1 order per cart item
    for item in cart:
        order = {
            "order_id": len(orders) + 1,
            "customer_name": data.customer_name,
            "delivery_address": data.delivery_address,
            "product": item["product_name"],
            "quantity": item["quantity"],
            "unit_price": item["unit_price"],
            "total_price": item["subtotal"]
        }

        orders.append(order)
        created_orders.append(order)

    # 🧹 Clear cart
    cart.clear()

    return {
        "message": "Order placed successfully",
        "orders_placed": len(created_orders),
        "orders": created_orders
    }


# =========================
# 📋 VIEW ORDERS
# =========================
@app.get("/orders")
def get_orders():
    return {
        "total_orders": len(orders),
        "orders": orders
    }