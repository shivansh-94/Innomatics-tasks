from fastapi import FastAPI

app = FastAPI()

# Sample products (order matters)
products = [
    {"id": 1, "name": "Wireless Mouse", "price": 499},
    {"id": 2, "name": "Notebook", "price": 99},
    {"id": 3, "name": "USB Hub", "price": 799},
    {"id": 4, "name": "Pen Set", "price": 49}
]


# 📄 PAGINATION
@app.get("/products/page")
def get_products_page(page: int = 1, limit: int = 2):

    total_products = len(products)

    # Calculate total pages
    total_pages = (total_products + limit - 1) // limit

    # Calculate start & end index
    start = (page - 1) * limit
    end = start + limit

    paginated_products = products[start:end]

    return {
        "page": page,
        "limit": limit,
        "total_pages": total_pages,
        "products": paginated_products
    }