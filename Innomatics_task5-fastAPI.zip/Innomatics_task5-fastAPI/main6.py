from fastapi import FastAPI, HTTPException
from typing import Optional

app = FastAPI()

# Sample products
products = [
    {"id": 1, "name": "Wireless Mouse", "price": 499},
    {"id": 2, "name": "Notebook", "price": 99},
    {"id": 3, "name": "USB Hub", "price": 799},
    {"id": 4, "name": "Pen Set", "price": 49}
]


@app.get("/products/browse")
def browse_products(
    keyword: Optional[str] = None,
    sort_by: str = "price",
    order: str = "asc",
    page: int = 1,
    limit: int = 4
):

    # 🔍 1. FILTER (Search)
    filtered = products
    if keyword:
        keyword_lower = keyword.lower()
        filtered = [
            p for p in products
            if keyword_lower in p["name"].lower()
        ]

    # ⚠️ Validation
    if sort_by not in ["price", "name"]:
        raise HTTPException(status_code=400, detail="sort_by must be 'price' or 'name'")

    if order not in ["asc", "desc"]:
        raise HTTPException(status_code=400, detail="order must be 'asc' or 'desc'")

    # 🔽 2. SORT
    reverse = True if order == "desc" else False

    if sort_by == "price":
        sorted_data = sorted(filtered, key=lambda x: x["price"], reverse=reverse)
    else:
        sorted_data = sorted(filtered, key=lambda x: x["name"].lower(), reverse=reverse)

    # 📄 3. PAGINATION
    total_found = len(sorted_data)
    total_pages = (total_found + limit - 1) // limit

    start = (page - 1) * limit
    end = start + limit
    paginated = sorted_data[start:end]

    return {
        "keyword": keyword,
        "sort_by": sort_by,
        "order": order,
        "page": page,
        "limit": limit,
        "total_found": total_found,
        "total_pages": total_pages,
        "products": paginated
    }