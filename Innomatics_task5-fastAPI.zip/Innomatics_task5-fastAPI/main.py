from fastapi import FastAPI, HTTPException

app = FastAPI()

# Sample products
products = [
    {"id": 1, "name": "Wireless Mouse", "price": 499},
    {"id": 2, "name": "Notebook", "price": 99},
    {"id": 3, "name": "USB Hub", "price": 649},
    {"id": 4, "name": "Pen Set", "price": 49}
]


# 🔍 SEARCH PRODUCTS
@app.get("/products/search")
def search_products(keyword: str):

    # Case-insensitive search
    keyword_lower = keyword.lower()

    results = [
        product for product in products
        if keyword_lower in product["name"].lower()
    ]

    # ⚠️ No results case
    if not results:
        return {
            "message": f"No products found for: {keyword}"
        }

    return {
        "total_found": len(results),
        "products": results
    }