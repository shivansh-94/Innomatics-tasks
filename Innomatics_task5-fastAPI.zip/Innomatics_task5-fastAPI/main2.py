from fastapi import FastAPI, HTTPException

app = FastAPI()

# Sample products
products = [
    {"id": 1, "name": "Wireless Mouse", "price": 499},
    {"id": 2, "name": "Notebook", "price": 99},
    {"id": 3, "name": "USB Hub", "price": 799},
    {"id": 4, "name": "Pen Set", "price": 49}
]


# 🔽 SORT PRODUCTS
@app.get("/products/sort")
def sort_products(sort_by: str = "price", order: str = "asc"):

    # ⚠️ Validate sort_by
    if sort_by not in ["price", "name"]:
        raise HTTPException(
            status_code=400,
            detail="sort_by must be 'price' or 'name'"
        )

    # ⚠️ Validate order
    if order not in ["asc", "desc"]:
        raise HTTPException(
            status_code=400,
            detail="order must be 'asc' or 'desc'"
        )

    # Sorting logic
    reverse = True if order == "desc" else False

    if sort_by == "price":
        sorted_products = sorted(products, key=lambda x: x["price"], reverse=reverse)
    else:  # sort_by == "name"
        sorted_products = sorted(products, key=lambda x: x["name"].lower(), reverse=reverse)

    return {
        "sort_by": sort_by,
        "order": order,
        "products": sorted_products
    }