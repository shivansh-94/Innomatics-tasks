from fastapi import FastAPI

app = FastAPI()

# Sample products
products = [
    {"id": 1, "name": "Wireless Mouse", "price": 499, "category": "Electronics"},
    {"id": 2, "name": "Notebook", "price": 99, "category": "Stationery"},
    {"id": 3, "name": "USB Hub", "price": 799, "category": "Electronics"},
    {"id": 4, "name": "Pen Set", "price": 49, "category": "Stationery"}
]


# 📊 SORT BY CATEGORY → THEN PRICE
@app.get("/products/sort-by-category")
def sort_by_category():

    # Sort by category first, then by price
    sorted_products = sorted(
        products,
        key=lambda x: (x["category"].lower(), x["price"])
    )

    return {
        "message": "Products sorted by category then price",
        "products": sorted_products
    }