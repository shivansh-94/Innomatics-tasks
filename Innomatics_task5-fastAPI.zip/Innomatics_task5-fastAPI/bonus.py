from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

# 📦 Orders storage
orders = []


# =========================
# 📝 CREATE ORDER (for testing)
# =========================
class OrderRequest(BaseModel):
    customer_name: str
    product: str
    quantity: int
    price: int


@app.post("/orders")
def create_order(order: OrderRequest):

    new_order = {
        "order_id": len(orders) + 1,
        "customer_name": order.customer_name,
        "product": order.product,
        "quantity": order.quantity,
        "total_price": order.quantity * order.price
    }

    orders.append(new_order)

    return {
        "message": "Order created",
        "order": new_order
    }


# =========================
# 📄 PAGINATE ORDERS
# =========================
@app.get("/orders/page")
def get_orders_page(page: int = 1, limit: int = 3):

    total_orders = len(orders)

    # Total pages calculation
    total_pages = (total_orders + limit - 1) // limit

    # Slice logic
    start = (page - 1) * limit
    end = start + limit

    paginated_orders = orders[start:end]

    return {
        "page": page,
        "limit": limit,
        "total_orders": total_orders,
        "total_pages": total_pages,
        "orders": paginated_orders
    }