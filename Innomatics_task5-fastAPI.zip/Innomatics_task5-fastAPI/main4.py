from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI()

# 📦 Orders storage
orders = []

# =========================
# 📝 CREATE ORDER (for testing)
# =========================
class OrderRequest(BaseModel):
    customer_name: str
    product: str
    quantity: int
    price: int


@app.post("/orders")
def create_order(order: OrderRequest):

    new_order = {
        "order_id": len(orders) + 1,
        "customer_name": order.customer_name,
        "product": order.product,
        "quantity": order.quantity,
        "total_price": order.quantity * order.price
    }

    orders.append(new_order)

    return {
        "message": "Order created",
        "order": new_order
    }


# =========================
# 🔍 SEARCH ORDERS
# =========================
@app.get("/orders/search")
def search_orders(customer_name: str):

    keyword = customer_name.lower()

    results = [
        order for order in orders
        if keyword in order["customer_name"].lower()
    ]

    # ⚠️ No results case
    if not results:
        return {
            "message": f"No orders found for: {customer_name}"
        }

    return {
        "customer_name": customer_name,
        "total_found": len(results),
        "orders": results
    }