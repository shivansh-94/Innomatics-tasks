from fastapi import FastAPI

app = FastAPI()

# Sample product data
products = [
    {"id": 1, "name": "Wireless Mouse", "category": "electronics", "price": 499},
    {"id": 2, "name": "Notebook", "category": "stationery", "price": 99},
    {"id": 3, "name": "USB Hub", "category": "electronics", "price": 799},
]

# ✅ New Endpoint
@app.get("/products/{product_id}/price")
def get_product_price(product_id: int):
    # Search for product
    for product in products:
        if product["id"] == product_id:
            return {
                "name": product["name"],
                "price": product["price"]
            }

    # If not found
    return {"error": "Product not found"}