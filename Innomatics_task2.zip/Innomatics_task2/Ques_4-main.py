from fastapi import FastAPI

app = FastAPI()

# Sample product data (with stock info)
products = [
    {"id": 1, "name": "Wireless Mouse", "category": "Electronics", "price": 499, "in_stock": True},
    {"id": 2, "name": "USB Hub", "category": "Electronics", "price": 799, "in_stock": True},
    {"id": 3, "name": "Notebook", "category": "Stationery", "price": 99, "in_stock": True},
    {"id": 4, "name": "Pen Set", "category": "Stationery", "price": 49, "in_stock": False},
]

# ✅ Summary Endpoint
@app.get("/products/summary")
def get_product_summary():
    total_products = len(products)

    in_stock_count = sum(1 for p in products if p["in_stock"])
    out_of_stock_count = total_products - in_stock_count

    # Most expensive product
    most_expensive_product = max(products, key=lambda x: x["price"])
    most_expensive = {
        "name": most_expensive_product["name"],
        "price": most_expensive_product["price"]
    }

    # Cheapest product
    cheapest_product = min(products, key=lambda x: x["price"])
    cheapest = {
        "name": cheapest_product["name"],
        "price": cheapest_product["price"]
    }

    # Unique categories
    categories = list(set(p["category"] for p in products))

    return {
        "total_products": total_products,
        "in_stock_count": in_stock_count,
        "out_of_stock_count": out_of_stock_count,
        "most_expensive": most_expensive,
        "cheapest": cheapest,
        "categories": categories
    }