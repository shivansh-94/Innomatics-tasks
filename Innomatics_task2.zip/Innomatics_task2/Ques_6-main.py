from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import List

app = FastAPI()

# 🗂️ In-memory storage
orders = []
order_counter = 1

# 🛡️ Order Model
class OrderItem(BaseModel):
    product_name: str
    quantity: int = Field(..., ge=1)

class Order(BaseModel):
    customer_name: str = Field(..., min_length=2)
    items: List[OrderItem]

# 📌 1. Create Order (status = pending)
@app.post("/orders")
def create_order(order: Order):
    global order_counter

    new_order = {
        "id": order_counter,
        "customer_name": order.customer_name,
        "items": [item.dict() for item in order.items],
        "status": "pending"
    }

    orders.append(new_order)
    order_counter += 1

    return {
        "message": "Order placed successfully",
        "order": new_order
    }

# 🔍 2. Get Order by ID
@app.get("/orders/{order_id}")
def get_order(order_id: int):
    for order in orders:
        if order["id"] == order_id:
            return order

    return {"error": "Order not found"}

# 🔄 3. Confirm Order (PATCH)
@app.patch("/orders/{order_id}/confirm")
def confirm_order(order_id: int):
    for order in orders:
        if order["id"] == order_id:
            order["status"] = "confirmed"
            return {
                "message": "Order confirmed successfully",
                "order": order
            }

    return {"error": "Order not found"}