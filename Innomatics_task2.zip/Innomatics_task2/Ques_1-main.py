from fastapi import FastAPI, Query
from typing import Optional, List

app = FastAPI()

# Sample product data (you can modify this)
products = [
    {"id": 1, "name": "Wireless Mouse", "category": "electronics", "price": 499},
    {"id": 2, "name": "USB Hub", "category": "electronics", "price": 799},
    {"id": 3, "name": "Notebook", "category": "stationery", "price": 100},
    {"id": 4, "name": "Pen", "category": "stationery", "price": 50},
]

@app.get("/products/filter")
def filter_products(
    min_price: Optional[int] = Query(None),
    max_price: Optional[int] = Query(None),
    category: Optional[str] = Query(None)
):
    filtered_products = products

    # Apply min_price filter
    if min_price is not None:
        filtered_products = [
            product for product in filtered_products
            if product["price"] >= min_price
        ]

    # Apply max_price filter
    if max_price is not None:
        filtered_products = [
            product for product in filtered_products
            if product["price"] <= max_price
        ]

    # Apply category filter
    if category is not None:
        filtered_products = [
            product for product in filtered_products
            if product["category"].lower() == category.lower()
        ]

    return filtered_products