from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import Optional, List

app = FastAPI()

# Store feedbacks
feedback = []

# ✅ Pydantic Model
class CustomerFeedback(BaseModel):
    customer_name: str = Field(..., min_length=2)
    product_id: int = Field(..., gt=0)
    rating: int = Field(..., ge=1, le=5)
    comment: Optional[str] = Field(None, max_length=300)

# ✅ POST Endpoint
@app.post("/feedback")
def submit_feedback(data: CustomerFeedback):
    # Convert model to dict
    feedback_data = data.dict()

    # Save to list
    feedback.append(feedback_data)

    return {
        "message": "Feedback submitted successfully",
        "feedback": feedback_data,
        "total_feedback": len(feedback)
    }