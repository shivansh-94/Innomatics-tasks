from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI()

# Initial products (already 4 items)
products = [
    {"id": 1, "name": "Pen", "price": 10, "category": "Stationery", "in_stock": True},
    {"id": 2, "name": "Notebook", "price": 50, "category": "Stationery", "in_stock": True},
    {"id": 3, "name": "Headphones", "price": 999, "category": "Electronics", "in_stock": True},
    {"id": 4, "name": "Keyboard", "price": 799, "category": "Electronics", "in_stock": True}
]

# Request model
class Product(BaseModel):
    name: str
    price: int
    category: str
    in_stock: bool

# GET all products
@app.get("/products")
def get_products():
    return {
        "total": len(products),
        "products": products
    }

# POST add product
@app.post("/products", status_code=201)
def add_product(product: Product):
    # Check duplicate name
    for p in products:
        if p["name"].lower() == product.name.lower():
            raise HTTPException(
                status_code=400,
                detail="Product with this name already exists"
            )

    # Auto-generate ID
    new_id = len(products) + 1

    new_product = {
        "id": new_id,
        "name": product.name,
        "price": product.price,
        "category": product.category,
        "in_stock": product.in_stock
    }

    products.append(new_product)

    return {
        "message": "Product added",
        "product": new_product
    }