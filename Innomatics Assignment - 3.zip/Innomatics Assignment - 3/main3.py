from fastapi import FastAPI, HTTPException

app = FastAPI()

# Initial data (ID 4 = Pen Set)
products = [
    {"id": 1, "name": "Notebook", "price": 50, "category": "Stationery", "in_stock": True},
    {"id": 2, "name": "Headphones", "price": 999, "category": "Electronics", "in_stock": True},
    {"id": 3, "name": "USB Hub", "price": 649, "category": "Electronics", "in_stock": True},
    {"id": 4, "name": "Pen Set", "price": 120, "category": "Stationery", "in_stock": False}
]

# ✅ GET all products
@app.get("/products")
def get_products():
    return {
        "total": len(products),
        "products": products
    }

# ✅ DELETE product
@app.delete("/products/{product_id}")
def delete_product(product_id: int):
    for index, product in enumerate(products):
        if product["id"] == product_id:
            deleted_name = product["name"]
            products.pop(index)

            return {
                "message": f"Product '{deleted_name}' deleted"
            }

    # If product not found
    raise HTTPException(
        status_code=404,
        detail={"error": "Product not found"}
    )