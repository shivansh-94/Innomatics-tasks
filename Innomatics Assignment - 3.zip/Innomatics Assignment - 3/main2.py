from fastapi import FastAPI, HTTPException
from typing import Optional

app = FastAPI()

# Initial data (USB Hub = ID 3, out of stock initially)
products = [
    {"id": 1, "name": "Pen", "price": 10, "category": "Stationery", "in_stock": True},
    {"id": 2, "name": "Notebook", "price": 50, "category": "Stationery", "in_stock": True},
    {"id": 3, "name": "USB Hub", "price": 799, "category": "Electronics", "in_stock": False},
    {"id": 4, "name": "Keyboard", "price": 799, "category": "Electronics", "in_stock": True}
]

# ✅ GET single product
@app.get("/products/{product_id}")
def get_product(product_id: int):
    for product in products:
        if product["id"] == product_id:
            return product
    raise HTTPException(status_code=404, detail="Product not found")


# ✅ PUT update product (partial update using query params)
@app.put("/products/{product_id}")
def update_product(
    product_id: int,
    in_stock: Optional[bool] = None,
    price: Optional[int] = None
):
    for product in products:
        if product["id"] == product_id:

            # Update fields if provided
            if in_stock is not None:
                product["in_stock"] = in_stock

            if price is not None:
                product["price"] = price

            return {
                "message": "Product updated",
                "product": product
            }

    # If product not found
    raise HTTPException(status_code=404, detail="Product not found")