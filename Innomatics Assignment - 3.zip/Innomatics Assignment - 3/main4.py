from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional

app = FastAPI()

# Initial products (you can adjust count based on previous tasks)
products = [
    {"id": 1, "name": "Notebook", "price": 50, "category": "Stationery", "in_stock": True},
    {"id": 2, "name": "Headphones", "price": 999, "category": "Electronics", "in_stock": True},
    {"id": 3, "name": "USB Hub", "price": 649, "category": "Electronics", "in_stock": True},
    {"id": 4, "name": "Keyboard", "price": 799, "category": "Electronics", "in_stock": True}
]

# Request model
class Product(BaseModel):
    name: str
    price: int
    category: str
    in_stock: bool


# ✅ GET all products
@app.get("/products")
def get_products():
    return {
        "total": len(products),
        "products": products
    }


# ✅ GET single product
@app.get("/products/{product_id}")
def get_product(product_id: int):
    for product in products:
        if product["id"] == product_id:
            return product
    raise HTTPException(status_code=404, detail="Product not found")


# ✅ POST add product
@app.post("/products", status_code=201)
def add_product(product: Product):
    # Duplicate check
    for p in products:
        if p["name"].lower() == product.name.lower():
            raise HTTPException(
                status_code=400,
                detail="Product with this name already exists"
            )

    new_id = len(products) + 1

    new_product = {
        "id": new_id,
        "name": product.name,
        "price": product.price,
        "category": product.category,
        "in_stock": product.in_stock
    }

    products.append(new_product)

    return {
        "message": "Product added",
        "product": new_product
    }


# ✅ PUT update product
@app.put("/products/{product_id}")
def update_product(
    product_id: int,
    price: Optional[int] = None,
    in_stock: Optional[bool] = None
):
    for product in products:
        if product["id"] == product_id:

            if price is not None:
                product["price"] = price

            if in_stock is not None:
                product["in_stock"] = in_stock

            return {
                "message": "Product updated",
                "product": product
            }

    raise HTTPException(status_code=404, detail="Product not found")


# ✅ DELETE product
@app.delete("/products/{product_id}")
def delete_product(product_id: int):
    for index, product in enumerate(products):
        if product["id"] == product_id:
            deleted_name = product["name"]
            products.pop(index)

            return {
                "message": f"Product '{deleted_name}' deleted"
            }

    raise HTTPException(status_code=404, detail="Product not found")